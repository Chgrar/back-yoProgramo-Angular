package com.chgrar.chg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChgApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChgApplication.class, args);
	}

}
